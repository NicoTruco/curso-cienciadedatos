nombre = "carlos Raul Ojeda Escalnate"
for x in (len(nombre)-1,-1)
   
print (nombre)