class Animal:
    resXMinuto=0

class Terrestre(Animal):
    cant_patas=4    

class Perro(Terrestre):
    altura=10 

pa1=Terrestre()

print("cuantas resXMintuo",pa1.resXMinuto)

pe1 = Perro()

print("cuantas resXMintuo Perro",pe1.resXMinuto)