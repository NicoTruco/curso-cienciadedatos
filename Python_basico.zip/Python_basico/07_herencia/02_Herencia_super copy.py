class Animal:
    resXMinuto=0

class Terrestre(Animal):
    cant_patas=4    

class Perro(Terrestre):
    altura=10
    def __init__(self,altura,cant_patas,resXMinuto):
        self.altura=altura
        self.cant_patas=cant_patas
        self.resXMinuto=resXMinuto
        if self.resXMinuto == 0:
            self.resXMinuto = 105

class Gato(Terrestre):
    altura=10
    def __init__(self,altura,cant_patas,resXMinuto):
        self.altura=altura
        self.cant_patas=cant_patas
        self.resXMinuto=resXMinuto
        if self.resXMinuto == 0:
            self.resXMinuto = 105


class Culebra(Terrestre):
    altura=10
    def __init__(self,altura,cant_patas,resXMinuto):
        self.altura=altura
        self.cant_patas=cant_patas
        self.resXMinuto=resXMinuto
        if self.resXMinuto == 0:
            self.resXMinuto = 105
            
pe1 = Perro(2,4,10)

print("cuantas resXMintuo Perro",pe1.resXMinuto)
print("cuantas cant_patas Perro",pe1.cant_patas)