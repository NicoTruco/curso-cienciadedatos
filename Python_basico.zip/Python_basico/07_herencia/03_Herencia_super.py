class Animal:
    __resXMinuto=0
    def __init__(self,resXMinuto):
        self.__resXMinuto=resXMinuto
        if self.__resXMinuto ==0:
           self.__resXMinuto =105
    @property
    def resXMinuto(self):
        return self.__resXMinuto + 1000

    def corre(self):
        print("Estoy Corriendo en 4 patas")

class Terrestre(Animal):
    cant_patas=0    
    def __init__(self,cant_patas,resXMinuto):
        self.cant_patas=cant_patas
        #Animal.__init__(self,resXMinuto)
        super().__init__(resXMinuto)

    def corre(self):
        print("El Terrestre Corre")
        super().corre()



class Perro(Terrestre):
    altura=10
    def __init__(self,altura,cant_patas,resXMinuto):
        self.altura=altura
        #Terrestre.__init__(self,cant_patas,resXMinuto)
        super().__init__(cant_patas,resXMinuto)

class Gusano(Terrestre):
    altura=10
    def __init__(self,altura,cant_patas,resXMinuto):
        self.altura=altura
        #Terrestre.__init__(self,cant_patas,resXMinuto)
        super().__init__(cant_patas,resXMinuto)

    def corre(self):
        print("Me Estoy Arrastrando, para arrancar del Harrys")
        super().corre()        


pe1 = Perro(2,4,0)

print("cuantas resXMintuo Perro",pe1.resXMinuto)
print("cuantas cant_patas Perro",pe1.cant_patas)

pe1.corre()

print("gusanito")
pg1 = Gusano(1,0,2)
pg1.corre()