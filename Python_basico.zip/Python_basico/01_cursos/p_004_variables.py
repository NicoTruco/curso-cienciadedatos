run= 788111    #un conjunto de valores, un solo valor en el instante
nombres= "Juanquin Andres"
apellidos= "Baeza Garcia"
direccion= "Basco 1094"


run1= 15
nombres1= "Mario Andres"
apellidos1= "Garcia"
direccion1= "Basco 1095"


run2= 15
nombres2= "Mario Andres"
apellidos2= "Garcia"
direccion2= "Basco 1095"


print(run, nombres1)