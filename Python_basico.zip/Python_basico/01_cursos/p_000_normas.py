# holaComoEstas    == Cada vez que cambia de palabra, inicia con mayúscula 
# Todas las variables y métodos parten con minúsuculas
# Las constantes Toda con mayuscula
    # EDAD = 18
# Las clases, inician cn mayúscula
# Las nombres, variable, etc, no pueden partir con número  
# jamas utilizar ñ, acentos o caracteres extraños