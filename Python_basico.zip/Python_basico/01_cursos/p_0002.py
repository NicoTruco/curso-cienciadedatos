## Utilizar parámetros de entrada
## dependiendo de los parámetro, funciona diferente  
## Servidor China
def sumar(p1,p2):
    total = p1 + p2
    #print("Total ", total)
    return total

###### Chile
r1=sumar(7,8)
r2=sumar(17,18)
print("resultados ",r1,r2)

"""
respuesta1 = sumar(17,8)
if (respuesta1 < 18):
    print("Vuelta a casa")    
else:
    print("entra a la disco")    
"""