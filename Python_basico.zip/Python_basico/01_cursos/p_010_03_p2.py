from p_010_01_CLPersona import Persona

pJuanito = Persona(1,"Juan","Vargas")
print("Estoy P222222222222222222222")
print(pJuanito.getRun(),pJuanito._nombres,pJuanito.__apPaterno)


## Ahora el alumno crea un archivo con la clase
## Luego crea un segundo archivo 
#           utilizando la clase del otro archivo