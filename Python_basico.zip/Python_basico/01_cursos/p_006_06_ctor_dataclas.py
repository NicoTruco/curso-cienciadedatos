from dataclasses import dataclass
@dataclass
class Persona:

    def __init__(self,run,nombres="Harrys Macarena",apPaterno="cualquier valor"):
        self.nroCliente = 1
        self.__run = run
        self.__nombres = nombres
        self.__apPaterno = apPaterno
        self.__apMaterno = ""
        self.__direccion = "Sin Dirección"


p1 = Persona(788111,"Juanquin Andres","Baeza")    
print("nroCliente",p1.nroCliente)
