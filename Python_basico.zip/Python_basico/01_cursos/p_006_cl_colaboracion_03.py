## Colaboracion

class Marca:
    id=0
    nombre=""
class Modelo:
    id=0
    nombre=""
    marca = Marca()
    #def __init__(self):
    #    self.marca = Marca()

class Auto:
    modelo = Modelo()
    anno = 0
    kilometraje = 0
    precio = 0
    #def __init__(self):
    #    self.modelo = Modelo()


## Observe que aunque no existe marca igual funciona
a1= Auto()
a1.modelo.marca.nombre = "Toyota"
a1.modelo.nombre = "Yaris"
a1.anno = 2020
a1.kilometraje = 1500
a1.precio = 7000000

a2= Auto()
a2.modelo.marca.nombre = "Nissan"
a2.modelo.nombre = "Sentra"
a2.anno = 2000
a2.kilometraje = 50000
a2.precio = 3000000 

print(a2.modelo.marca.nombre)