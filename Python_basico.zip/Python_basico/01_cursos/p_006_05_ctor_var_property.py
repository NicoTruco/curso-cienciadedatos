
class Persona:

    def __init__(self,run,nombres="Harrys Macarena",apPaterno="cualquier valor"):
        self.nroCliente = 1
        self.__run = run
        self.__nombres = nombres
        self.__apPaterno = apPaterno
        self.__apMaterno = ""
        self.__direccion = "Sin Dirección"

    # por viejo utilizo getNombre, pero como es propiedad
    # debiera ser solo def nombres(self)    
    @property
    def getNombres(self):
        return self.__nombres

        
    def getCliente(self):
        # juanito pidio la variable, auditoria
        return self.nroCliente 

    def setCliente(self,nroCliente):
        self.nroCliente  = nroCliente

    @getNombres.setter
    def setNombres(self,nombres):
        self.__nombres = nombres       


p1 = Persona(788111,"Juanquin Andres","Baeza")    
print("nroCliente",p1.nroCliente)
print("getCliente",p1.getCliente())
print("Nombre",p1.getNombres) # la utilizo sin parentesis
                # es como si fuera una variable

#p1.setNombres("Hola")
p1.setNombres="Hola asigna"
p1.setCliente(8758)
print("Nombre set",p1.getNombres) # la utilizo sin parentesis
print("NroCliente set",p1.getCliente()) # la utilizo sin parentesis


