#JuanDiegoVargas  
#juanDiegoVargas  ==>Todas las variables inician con minúsculas
       # cada vez que cambia de palabra mayuscula o _
       #juan_diego_vargas
       #juanDiegoVargas


class Persona:
    #Observe que se eliminaron los campos
    # cada vez que uso self, automáticamente se crea la variable
   
    def __init__(self,run,nombres,apPaterno):
        self.run = run
        self.nombres = nombres
        self.apPaterno = apPaterno
        self.apMaterno = ""
        self.direccion = ""
        self.dv = "*"

    def calculaDv(self):
        self.dv = self.run + "-"+ "7"
    # Get Set
    def getRun(self):
        return self.run

    def camina():  # Método Static
        print("Caminando")
        #print("run",self.run) Error no se puede utilizar self

    def contrabando(self):
        print(self.nombres, "Camina hasta la frontera")


Persona.camina()