#JuanDiegoVargas  
#juanDiegoVargas  ==>Todas las variables inician con minúsculas
       # cada vez que cambia de palabra mayuscula o _
       #juan_diego_vargas
       #juanDiegoVargas

# Para obligar, a la persona que me ocupe
#       , me pase cierta cantidad de parámetros        
class Moto:
    color=""
    def __init__(self):
        color="rosado"

class Persona:
    run = 0
    nombres=""
    apPaterno=""
    apMaterno="" 
    direccion=""
    # self == this
    # los opcionales siempre van al final
    def __init__(self,run,nombres="Harrys Macarena",apPaterno="cualquier valor"):
        self.run = run
        self.nombres = nombres
        self.apPaterno = apPaterno
        self.apMaterno = ""
        self.direccion = "Sin Dirección"




p1 = Persona(788111,"Juanquin Andres","Baeza")    
print("uno",p1.nombres,p1.apPaterno,p1.direccion)

p1.run = 87 
p1.nombres = "**"

print("dos",p1.nombres,p1.apPaterno,p1.direccion)

p2 = Persona(788111,"Juanquin Andres")    
print("p2",p2.nombres,p2.apPaterno,p2.direccion)

p3 = Persona(123,apPaterno="simms")    
print("p2",p3.nombres,p3.apPaterno,p3.direccion)