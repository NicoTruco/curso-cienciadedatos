# En La mayoria de los lenguajes 
# en un IF se puede realizar una expresión
def ifExpresion(num1,num2):
    print("resto ", num1 - num2)
    if (num1 - num2):
       return ("Verdadero")
    else:
       return ("Falso")

# Testeamos la aplicación 
print ("Val 1,1",ifExpresion(1,1))
print ("***********")
print ("Val 1,5",ifExpresion(1,5))
