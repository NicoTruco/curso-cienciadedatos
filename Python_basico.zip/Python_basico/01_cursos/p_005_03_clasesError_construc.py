class Perro:
	edad=""
	nombre=""
	raza=""
	direccion=""
	def __init__(self,edad,nombre,raza,direccion):
		#print("pase********")
		self.edad=edad
		self.nombre=nombre
		self.raza=raza
		self.direccion=direccion


#print("111111")	
p1=Perro(16,"Sultan","kiltro","av. siempre viva 123")
#print("2222")	


p2=Perro(16,"Rambo","kiltro","av. siempre viva 132")

print(p1.nombre + "-" + str(p1.edad) +"-" + p1.raza +"-",p1.direccion)
print(p2.nombre + "-" + str(p2.edad) +"-" + p2.raza +"-",p2.direccion)
print(p2.nombre , p2.edad, p2.raza ,p2.direccion)