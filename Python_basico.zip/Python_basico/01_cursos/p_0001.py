##   Definir Métodos, para su posterior uso
## Ver Parametros opcionales
def comprarPan(cuantos=1):
    # Puendo encapsular un conjunto de instrucciones
    print("hOla como estas")

    for x in range(1,11):
        print("Hola Harrys",x)

    return 25


comprarPan()
res2= comprarPan()
res3= comprarPan()
res4= comprarPan()


#print("res1",res)
print("res2",res2)
print("res3",res3)
print("res4",res4)

####################################
def comprarPan_v2(cuantos):
    # Puendo encapsular un conjunto de instrucciones
    for x in range(cuantos):
        print("saco un pan nro:",x + 1)




comprarPan_v2(5)
print("*********")
comprarPan_v2(3)
print("*********")
comprarPan_v2(15)
print("*********")