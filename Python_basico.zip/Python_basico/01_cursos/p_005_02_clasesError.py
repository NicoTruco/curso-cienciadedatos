class Perro:
	edad=""
	nombre=""
	raza=""
	direccion=""
	
p1=Perro()

p1.edad=16
p1.nombre="Sultan"
p1.raza="kiltro"
p1.direccion="av. siempre viva 123"

p2=Perro()
"""
 ERRROROROORORROOROROROR
p2.dad=6
p1.nombre="Rambo"
p1.raza="kiltro"
p1.direccion="av. siempre viva 132"
*/
"""
#p2.dad=6
p2.edad=6
p2.nombre="Rambo"
p2.raza="kiltro"
p2.direccion="av. siempre viva 132"

print(p1.nombre + "-" + str(p1.edad) +"-" + p1.raza +"-",p1.direccion)
print(p2.nombre + "-" + str(p2.edad) +"-" + p2.raza +"-",p2.direccion)
print(p2.nombre , p2.edad, p2.raza ,p2.direccion)