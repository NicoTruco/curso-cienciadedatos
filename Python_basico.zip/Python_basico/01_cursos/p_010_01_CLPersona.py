class Persona:
    
    def __init__(self,run,nombres,apPaterno,apMaterno="***"):
        self.maaati = run
        self._nombres = nombres  # Supuestamente es protected
        self.__apPaterno = apPaterno   # Privada
        self.apMaterno = apMaterno
        self.direccion = ""
        self.dv = "*"
        print("Pase por el constructor")
    def getRun(self):
        print("interno __apPaterno" ,self.__apPaterno)
        print("_nombres" ,self._nombres)
        ###   Puedo colocar validaciones
        return self.maaati
          


class Moto:
    
    def __init__(self,run,nombres,apPaterno,apMaterno="***"):
        self.run = run
        self.nombres = nombres
        self.apPaterno = apPaterno
        self.apMaterno = apMaterno
        self.direccion = ""
        self.dv = "*"
        print("Pase por el constructor")


