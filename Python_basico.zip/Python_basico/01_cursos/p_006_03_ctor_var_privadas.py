#JuanDiegoVargas  
#juanDiegoVargas  ==>Todas las variables inician con minúsculas
       # cada vez que cambia de palabra mayuscula o _
       #juan_diego_vargas
       #juanDiegoVargas

# private si funciona, se utiliza "__" doble guión  
class Persona:

    def __init__(self,run,nombres="Harrys Macarena",apPaterno="cualquier valor"):
        self.nroCliente = 1
        self.__run = run
        self.__nombres = nombres
        self.__apPaterno = apPaterno
        self.__apMaterno = ""
        self.__direccion = "Sin Dirección"
    def getNombre(self):
        return self.__nombres
    def getCliente(self):
        # juanito pidio la variable, auditoria
        return self.nroCliente + 5000000



p1 = Persona(788111,"Juanquin Andres","Baeza")    
#print("uno",p1.__nombres,p1.__apPaterno,p1.__direccion)
print("nroCliente",p1.nroCliente)
print("getCliente",p1.getCliente())
print("Nombre",p1.getNombre())


