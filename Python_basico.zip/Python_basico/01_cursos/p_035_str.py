str = 'Hola*mundo!'

print ("str " ,str) # Imprime una cadena completa
print ("str [0]   ==>" ,str [0]) # Imprime el primer carácter de la cadena
print ("str [2:5] ==>" ,str [2: 5]) # Imprime caracteres desde el 3 al 5
print ("str [2:]  ==>" ,str [2:]) # Imprime la cadena a partir del 3er carácter
aaa = str * 3
print (aaa) # Imprime cadena tres veces
print (str + "TEST") # Imprime una cadena concatenada
