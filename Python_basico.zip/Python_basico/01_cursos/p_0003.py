## Recibimos 4 parámetros
## no creamos antas variables como el anterior
## Recepcionamos la el resultado en una variable 


def multiplicar(p1,p2,p3,p4):
    #total = p1 * p2 * p2 * p3 * p4
    #return total
    return p1 * p2 * p2 * p3 * p4


r1=multiplicar(7,8,7,89)
r2=multiplicar(17,18,34,56)
print("resultados ",r1,r2)
