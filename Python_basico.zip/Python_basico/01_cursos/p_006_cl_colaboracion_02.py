class marca:
    id=0
    nombre=""
class modelo:
    id=0
    nombre=""
    marca =0

class Auto:
    modelo = ""
    anno = 0
    kilometraje = 0
    precio = 0


## Observe que aunque no existe marca igual funciona
a1= Auto()
a1.marca = "Toyota"
a1.modelo = "Yaris"
a1.anno = 2020
a1.kilometraje = 1500
a1.precio = 7000000

a2= Auto()
a2.marca = "Nissan"
a2.modelo = "Sentra"
a2.anno = 2000
a2.kilometraje = 50000
a2.precio = 3000000 

print(a2.marca)