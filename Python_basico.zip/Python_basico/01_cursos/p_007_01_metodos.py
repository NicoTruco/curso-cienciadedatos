#JuanDiegoVargas  
#juanDiegoVargas  ==>Todas las variables inician con minúsculas
       # cada vez que cambia de palabra mayuscula o _
       #juan_diego_vargas
       #juanDiegoVargas


class Persona:
    #Observe que se eliminaron los campos
    # cada vez que uso self, automáticamente se crea la variable
   
    def __init__(self,run,nombres,apPaterno):
        self.run = run
        self.nombres = nombres
        self.apPaterno = apPaterno
        self.apMaterno = ""
        self.direccion = ""
        self.dv = "*"

    def calculaDv(self):
        self.dv = "7"
    # Get Set
    def getRun(self):
        return self.run

    def contrabando(self):
        print(self.nombres, "Camina hasta la frontera")
        print(self.nombres, "cruza la frontera")
        print(self.nombres, "compra dulces")
        print(self.nombres, "vuelva a cruzar la frontera")
        print(self.nombres, "arranca jajajaj")

    

p1 = Persona(788111,"Juanquin Andres","Baeza")    
print("uno",p1.nombres,p1.apPaterno,p1.direccion,p1.dv)
p1.contrabando()

p1.run = 87 
p1.nombres = "**"
p1.calculaDv()

print("dos",p1.nombres,p1.apPaterno,p1.direccion,p1.dv)

p2 = Persona(15,"Harryssito","***") 
p2.contrabando()

print("run1 ",p1.getRun())
print("run2 ",p2.getRun())



