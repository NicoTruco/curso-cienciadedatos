from p_010_01_CLPersona import Persona


print("Etapa1")
p1 = Persona(1,"Juan","Vargas")
print("despues del constructor el run =",p1.getRun())


print("Estoy en el principal")
print(p1.getRun(),p1._nombres,"p1.__apPaterno")
p2 = Persona(2,"Juan","Vargas")
p3 = Persona(3,"Juan","Vargas")
p4 = Persona(4,"Juan","Vargas")
print("despues del constructor el run =",p2.getRun())
print("despues del constructor el run =",p3.getRun())
print("despues del constructor el run =",p4.getRun())