#pip install reportlab
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
c = canvas.Canvas("meza.pdf", pagesize=A4)
c.drawString(30, 50, "Hola como estas") 
c.drawString(30, 150, "Hola como estas 150") 
c.circle(100,  75, 10)
c.save()