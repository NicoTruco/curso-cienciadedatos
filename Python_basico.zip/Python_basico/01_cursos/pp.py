class Persona:
    run = "2"
    def __init__(self,run):
        self.run = run

p1= Persona("3")
print(p1.run)        
p1.run = "445"
print(p1.run)        
p1.run = "335"
print(p1.run)        
del p1.run
print(p1.run)        