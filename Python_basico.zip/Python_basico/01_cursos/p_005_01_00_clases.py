#JuanDiegoVargas  
#juanDiegoVargas  ==>Todas las variables inician con minúsculas
       # cada vez que cambia de palabra mayuscula o _
       #juan_diego_vargas
       #juanDiegoVargas


class Persona:
    run = 0
    nombres="Nombre Original"
    apPaterno=""
    apMaterno="" 
    direccion=""
 

# instancia
p1 = Persona()    
p2 = Persona()    

# Cuando utilizo variables desde afuera, es como si se creara una segunda variable
# Observar en el siguiente ejercicio, que suaede si lo utilizo con self

p1.run = 788111   
p1.nombres = "Juanquin Andres"
p1.apPaterno = "Baeza"
p1.apMaterno =  "Garcia"
p1.direccion =  "Basco 1094"


p2 = Persona()    
p2.run = 788111 
p2.nombres = "Juanquin2 Andres"
p2.apPaterno = "Baeza2"
p2.apMaterno =  "Garcia2"
p2.direccion =  "Basco2 1094"

p3 = Persona() 
p4 = Persona() 
p5 = Persona() 
p6 = Persona() 

print("nombre 00 ",p2.nombres)

p2.nombres = "Harrysito"
print("nombre 11",p2.nombres)
p2.nombres = "pedrito"
print("nombre 22",p2.nombres)
del p2.nombres
print("nombre 33",p2.nombres)

# El alumno crea una clase (ojala 2)
# Crea al menos dos instancias
# al menos imprime una instancia completa