def forRanoInicioFinal(msg,num2):
    # Range parámetros Sin inicio solo Final
    # Inicia siempre desde CERO
    for x in range(num2):
    	print("Número", x, msg)
# Testeamos la aplicación 
forRanoInicioFinal("1,10 Veces",10)
print("******************************")
forRanoInicioFinal("5,10 Veces",5)
