#JuanDiegoVargas  
#juanDiegoVargas  ==>Todas las variables inician con minúsculas
       # cada vez que cambia de palabra mayuscula o _
       #juan_diego_vargas
       #juanDiegoVargas

# protected no funciona, solo como norma utilizamos "_" un guión bajo

class Persona:

    def __init__(self,run,nombres="Harrys Macarena",apPaterno="cualquier valor"):
        self.nroCliente = 1
        self._run = run
        self._nombres = nombres
        self._apPaterno = apPaterno
        self._apMaterno = ""
        self._direccion = "Sin Dirección"
    def getNombre(self):
        return self._nombres
    def getCliente(self):
        # juanito pidio la variable, auditoria
        return self.nroCliente + 5000000



p1 = Persona(788111,"Juanquin Andres","Baeza")    
print("protected uno",p1._nombres,p1._apPaterno,p1._direccion)
print("nroCliente",p1.nroCliente)
print("getCliente",p1.getCliente())
print("Nombre",p1.getNombre())


