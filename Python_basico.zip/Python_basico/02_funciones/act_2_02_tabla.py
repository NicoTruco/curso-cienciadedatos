tabla = int(input("Ingrese Tabla Multiplicar : "))
print(" usted eligio la tabla del : ", tabla)

calcula = tabla * 1
#calcula asigna el resultado de => tabla * 1
#                                  6     * 1
print(tabla , " x 1 = ", calcula)

calcula = tabla * 2
#                                  6     * 2

print(tabla , " x 2 = ", calcula)

calcula = tabla * 3
print(tabla , " x 3 = ", calcula)


calcula = tabla * 4
print(tabla , " x 4 = ", calcula)


calcula = tabla * 5
print(tabla , " x 5 = ", calcula)


calcula = tabla * 6
print(tabla , " x 6 = ", calcula)
