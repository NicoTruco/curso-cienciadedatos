import math
radio = int(input("Ingrese radio: "))
haltura = int(input("Ingrese haltura:"))
vol = 3.14 * (radio * radio) * haltura
print("El Volumen es ", vol )





