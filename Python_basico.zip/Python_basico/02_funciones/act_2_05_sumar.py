n1 = int(input("Ingrese Nro 1 : "))
n2 = int(input("Ingreso nro 2 : "))
n3 = int(input("Ingreso nro 3 : "))
print(f"   nro1 = {n1}    nro2= {n2} nro3= {n3}")

resul = n1 + n2 + n3
print(f"   la suma es : {resul}")

if (resul > 10):
	print("la suma es mayor que 10")
else:
	print("la suma NO es Mayor que 10")
