hasta = int(input("Viejo pesado hasta que nro quieres : "))
for i in range(1,hasta+1):
	if (i%2 == 1):
	    print(f"Número Impar {i}")

for i in range(1,hasta+1):
	if (i%2 == 0):
	    print(f"Número Par {i}")	    