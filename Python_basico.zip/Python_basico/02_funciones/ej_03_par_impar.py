nro = int(input("Ingrese número: "))
#19  19 / 2 = 9 1 modulo resto
if nro % 2 == 1: 
    print("El número es impar ")
else:
    print("El número es par ")    





