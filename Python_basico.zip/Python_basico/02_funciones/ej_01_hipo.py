import math
cata = int(input("Ingrese Cateto a : "))
catb = int(input("Ingrese Cateto b :"))
#c2 = a2 + b2
#c  = raiz(a2 + b2)
#c = raiz( (a*a)  + (b*b)  )
c = math.sqrt( (cata*cata)  + (catb*catb)  )
print("La Hipotenusa es ", c)





