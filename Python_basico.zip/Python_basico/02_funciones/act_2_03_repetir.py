tabla = int(input("Ingrese Tabla Multiplicar : "))
print(" usted eligio la tabla del : ", tabla)

"""
for i in range(1,11):
    #print(f"{i} ")
    calcula = tabla * i
    #print(tabla , " x ",i," = ", calcula)
    print(f" {tabla} x  {i} = {calcula}")

"""
for i in range(1,11):
	print(f"M {tabla} x  {i} = {tabla * i}")