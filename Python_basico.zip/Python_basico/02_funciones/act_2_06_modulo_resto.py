n1 = int(input("Ingrese Nro 1 : "))
print(f"   nro1 = {n1} ")

if n1 % 2 == 1:
    print("print impar")
else:
	print(" es par")

