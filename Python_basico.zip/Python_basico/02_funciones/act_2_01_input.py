nombre = input("ingrese su nombre : ")
dir    = input("Ingresa tu direccion : ")
rut    = int(input("Ingresa su Rut :"))
edad    = int(input("Ingresa su edad :"))

print("Tu Nombre es :", nombre)
print("Tu direccion es :", dir)
print("Tu rut es :", rut)
print("Tu edad es :", edad)