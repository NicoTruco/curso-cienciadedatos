a  = 3
b = 2
c = 11
d = 13

if a == 3:
	print("Es un 3")


if a == 4:
	print("Es un 4")

if a != 3:
	print("No es 3")

if a == 3 and (b == 7 or c == 10) and d==13:
	print("OPCION 11111111")
else:	
	print("OPCION 22222")	