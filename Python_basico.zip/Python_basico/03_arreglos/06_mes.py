arr_mes = ["Enero","Febrero","Marzo"]
arr_dia = ["31","28","31"]
mes  = int(input("Ingrese el mes : "))

print(f"Mes : {mes} Nombre {arr_mes[mes-1]} dias : {arr_dia[mes-1]}")
