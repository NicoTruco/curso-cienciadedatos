import rutinas as harrys


tot = harrys.sumar(7,10)
tot1 = harrys.sumar(70,100)
#print("Totales : ", tot," Total 2", tot1)
print(f"Totales : {tot} Total 2 {tot1}  Total 2 {tot1 +700}")