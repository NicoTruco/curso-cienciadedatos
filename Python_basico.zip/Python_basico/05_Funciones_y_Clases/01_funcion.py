print("Hola")
n1 = 11
n2 = 2000
resu = n1 + n2
print("Resultado ", resu)



n1 = 100
n2 = 3000
resu = n1 + n2
print("Resultado ", resu)


n1 = 400
n2 = 500
resu = n1 + n2
print("Resultado ", resu)
