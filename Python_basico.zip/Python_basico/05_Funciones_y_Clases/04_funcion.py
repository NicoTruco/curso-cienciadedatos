def comprarPan(pan,cerveza = 2,cigarros = 1):
    print("*******************: ")
    print("compro pan: ", pan)
    print("compro cerveza: ", cerveza)
    print("compro cigarros: ", cigarros)


#dia 1
comprarPan(2)
#dia 2
comprarPan(2)

#dia 3
comprarPan(10,15)


#dia 4
comprarPan(10,20,10)
