#Reglas



"""
hola como estas muy bien

Tipos Lenguajes
    Los que distingues mayusculas y minusculas
         HolaComoEstasMuyBien
    Los que NOOOOOOO distingues mayusculas y minusculas
         hola_como_estas_muy_bien
"""

# El problema de esto es que tendre que crear tantas variables
#  como objetos existan
# si un objeto tiene 50 variable de almacenamiento (rut,nombrs,calle, nacionalidad,etc)
# y tengo 3 instancias, tendré que crear 150 variables
rut1 = 78
nombres1 = "Juanito"    
apPaterno1 = "Harrys"    
apMaterno1 = "Marilad"    

rut2 = 78
nombres2 = "Juanito"    
apPaterno2 = "Harrys"    
apMaterno2 = "Marilad"    

rut3 = 78
nombres3 = "Juanito"    
apPaterno3 = "Harrys"    
apMaterno3 = "Marilad"    