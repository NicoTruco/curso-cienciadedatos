###  OJO No Compila
###  Solo Conceptual

suma = 7 + "8"
#      nro + texto == por que esta encerrado entre cremillas
# Seria lo mismo  "7" + "8"   == "78"

# Castin implicito== que el computador decide
pagar = 9  + 10.5  == integer  + double
# 1ra alter   9  + 10

# Castin explicito== yo claramente le digo al computador lo que haga
pagar = (double) 9 + (double) 10.5  = double 19.5


print("suma ", suma)