def suma(n1,n2):
    # ahora los recibo como parámetros
    #n1 = 11
    #n2 = 2000
    resu = n1 + n2
    print("Resultado ", resu)

suma(11,2000)
suma(100,3000)
suma(400,500)


def my_function(country = "Harrys"):
  print("I am from " + country)

my_function("Juanikto")
my_function("Pedrio")
my_function()
my_function()
my_function()
my_function("Maria")

